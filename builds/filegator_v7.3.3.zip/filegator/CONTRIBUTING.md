## Contributing to FileGator

- File an issue before submitting a pull request
- Please talk to a maintainer before submitting a pull request
- Please make sure Continuous Integration passes

## Where to report bugs?

- Please report all bugs in this repository's issues tracker.
