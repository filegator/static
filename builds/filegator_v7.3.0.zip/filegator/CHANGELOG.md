# Chanelog

## 7.3.0 - 2020-02-25

* Search feature

## 7.2.1 - 2020-02-21

* Better editor & image gallery
* New config: `editable` (file extensions that can be opened with editor)
* New config: `date_format`

## 7.2.0 - 2020-02-20

* File preview & edit feature added (preview images, edit txt files)

## 7.1.6 - 2020-01-12

* Translations added, Bulgarian, Serbian, French

## 7.1.5 - 2020-01-09

* Translations added, Dutch, Chinese

## 7.1.4 - 2019-12-30

* npm updates, vue & vue-cli

## 7.1.3 - 2019-12-04

* Symfony update, fixes CVE-2019-18888

## 7.1.2 - 2019-09-09

* Fix for filename sanitize/cut during upload process

## 7.1.1 - 2019-09-05

* Fix for multibyte filename uploads

## 7.1.0 - 2019-09-05

* Fix for UTF8 filename issues (#12) - may brake existing download links generated with previous versions

## 7.0.1 - 2019-08-01

* Fixed file upload bug - merging chunks after upload was failing

## 7.0.0 - 2019-07-26

* Initial release
