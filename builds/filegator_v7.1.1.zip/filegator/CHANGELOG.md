# Chanelog

## 7.1.1 - 2019-09-05

* Fix for multibyte filename uploads

## 7.1.0 - 2019-09-05

* Fix for UTF8 filename issues (#12) - may brake existing download links generated with previous versions

## 7.0.1 - 2019-08-01

* Fixed file upload bug - merging chunks after upload was failing

## 7.0.0 - 2019-07-26

* Initial release
