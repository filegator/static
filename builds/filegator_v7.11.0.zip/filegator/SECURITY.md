# Security Policy

## Reporting a Vulnerability

If you discover any security related issues, please email alcalbg@gmail.com instead of using the issue tracker.

