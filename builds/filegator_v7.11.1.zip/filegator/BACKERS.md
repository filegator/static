# Sponsors & Backers

FileGator is a free, open-source project. It's an independent project with its ongoing development made possible entirely thanks to the support by these awesome [backers](https://github.com/filegator/filegator/blob/master/BACKERS.md). If you'd like to join them, please consider:

- [Become a backer or sponsor on Patreon](https://www.patreon.com/alcalbg).

## Sponsors
<table>
  <tbody>
    <tr>
      <td align="center" valign="middle">
        <a href="https://www.linkpreview.net/?utm_campaign=Sponsored%20GitHub%20FileGator" target="_blank">
          <img title="Preview Web Links with our Free API service. Get JSON Response for any URL" width="177px" src="https://www.linkpreview.net/images/logo-dark.png">
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="https://www.getping.info/?utm_campaign=Sponsored%20GitHub%20FileGator" target="_blank">
          <img title="Trigger an email, sms or slack notification with a simple GET request" width="177px" src="https://www.getping.info/img/logo.svg">
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="https://correctme.app/?utm_campaign=Sponsored%20GitHub%20FileGator" target="_blank">
          <img title="Free Online Grammar and Spell Checker" width="177px" src="https://correctme.app/logo.png">
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="https://interactive32.com/?utm_campaign=Sponsored%20GitHub%20FileGator" target="_blank">
          <img title="Modern approach to software development" width="177px" src="https://interactive32.com/images/logo.png">
        </a>
      </td>
    </tr><tr></tr>
  </tbody>
</table>

## Backers

- Tobias (Biast12) 🇩🇰  [https://twitter.com/Biast12](https://twitter.com/Biast12)

